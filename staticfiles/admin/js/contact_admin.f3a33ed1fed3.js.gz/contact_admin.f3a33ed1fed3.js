(function($) {
    $(document).ready(function() {
        $('#searchbar').attr('placeholder', 'Search email here');
    });
})(django.jQuery);
