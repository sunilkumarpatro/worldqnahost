(function($) {
    $(document).ready(function() {
        $('#searchbar').attr('placeholder', 'Search comment here');
    });
})(django.jQuery);