(function($) {
    $(document).ready(function() {
        $('#searchbar').attr('placeholder', 'Search English title here');
    });
})(django.jQuery);