(function($) {
    $(document).ready(function() {
        $('#searchbar').attr('placeholder', 'Search related here');
    });
})(django.jQuery);